# 🦁 BetAfrik v2.0 — Backend Supabase + Netlify/Render

## 📁 Structure du projet
```
betafrik/
├── src/
│   ├── App.js          ← Application React complète
│   ├── index.js        ← Point d'entrée
│   └── lib/
│       ├── supabase.js ← Client Supabase
│       └── api.js      ← Toutes les fonctions API
├── public/
│   └── index.html
├── supabase_schema.sql ← À coller dans Supabase SQL Editor
├── .env.example        ← Modèle de variables d'environnement
├── netlify.toml        ← Config Netlify
├── render.yaml         ← Config Render
└── package.json
```

## 🚀 ÉTAPE 1 — Configurer Supabase (gratuit)

1. Allez sur **https://supabase.com** → "Start your project"
2. Créez un projet (choisissez région **West EU** ou **South Asia**)
3. Allez dans **SQL Editor** → collez tout le contenu de `supabase_schema.sql` → **Run**
4. Allez dans **Settings → API** et copiez :
   - `Project URL` → c'est votre `REACT_APP_SUPABASE_URL`
   - `anon public key` → c'est votre `REACT_APP_SUPABASE_ANON_KEY`

## 🚀 ÉTAPE 2 — Mettre le code sur GitHub

1. Créez un repo sur **github.com** (ex: `betafrik`)
2. Uploadez tous les fichiers de ce ZIP

## 🚀 ÉTAPE 3A — Déployer sur Netlify

1. **netlify.com** → "Add new site" → "Import from Git"
2. Choisissez votre repo GitHub
3. Dans **"Environment variables"** ajoutez :
   - `REACT_APP_SUPABASE_URL` = votre URL Supabase
   - `REACT_APP_SUPABASE_ANON_KEY` = votre clé Supabase
4. Cliquez **Deploy** ✅

## 🚀 ÉTAPE 3B — Déployer sur Render (alternative)

1. **render.com** → "New Web Service"
2. Connectez votre repo GitHub
3. Ajoutez les variables d'environnement Supabase
4. Cliquez **Create Web Service** ✅

## ✅ Fonctionnalités avec Supabase

| Fonctionnalité | Détail |
|---|---|
| **Inscription/Connexion** | Auth Supabase sécurisée |
| **Profil utilisateur** | Nom, téléphone, solde en base |
| **Bonus bienvenue** | 500 FCFA offerts automatiquement |
| **Paris en temps réel** | Supabase Realtime (WebSocket) |
| **Historique des paris** | Persisté en base de données |
| **Transactions** | Dépôts et paris enregistrés |
| **Sécurité RLS** | Chaque user voit seulement ses données |

## 💳 Paiements Mobile Money
- Orange Money, Wave, MTN MoMo, Moov Money, CinetPay
- Intégration CinetPay API : https://cinetpay.com/developers
