import { useState, useEffect, useCallback } from "react";
import { supabase } from "./lib/supabase";
import * as api from "./lib/api";

const C = {
  bg: "#0A0E1A", surface: "#111827", card: "#1A2235", border: "#1E2D45",
  accent: "#F5A623", accentDark: "#C47D0E", green: "#00C853", red: "#FF3D57",
  text: "#E8EDF5", muted: "#6B7A99", highlight: "#243049",
};

const SPORTS = [
  { id: "foot", label: "⚽ Football" },
  { id: "basket", label: "🏀 Basket" },
  { id: "tennis", label: "🎾 Tennis" },
  { id: "rugby", label: "🏉 Rugby" },
];

const PAYMENTS = ["Orange Money", "Wave", "MTN MoMo", "Moov Money", "CinetPay"];

const inp = {
  width: "100%", padding: "11px 14px", borderRadius: 9,
  border: `1px solid ${C.border}`, background: C.card,
  color: C.text, fontSize: 14, boxSizing: "border-box", marginBottom: 12,
};

// ─── Toast ───────────────────────────────────────────
function Toast({ msg, type }) {
  return (
    <div style={{
      position: "fixed", top: 20, left: "50%", transform: "translateX(-50%)",
      background: type === "error" ? C.red : C.green,
      color: "#fff", padding: "12px 22px", borderRadius: 10, zIndex: 2000,
      fontSize: 13, fontWeight: 600, boxShadow: "0 4px 24px #0008",
      animation: "slideIn .3s ease", maxWidth: 340, textAlign: "center",
    }}>{msg}</div>
  );
}

// ─── Modal ───────────────────────────────────────────
function Modal({ title, onClose, children }) {
  return (
    <div style={{ position: "fixed", inset: 0, background: "#000a", zIndex: 999, display: "flex", alignItems: "center", justifyContent: "center", padding: 20 }}>
      <div style={{ background: C.surface, border: `1px solid ${C.border}`, borderRadius: 16, padding: 24, maxWidth: 430, width: "100%", position: "relative", maxHeight: "90vh", overflowY: "auto" }}>
        <button onClick={onClose} style={{ position: "absolute", top: 12, right: 14, background: "none", border: "none", color: C.muted, fontSize: 22, cursor: "pointer" }}>×</button>
        <h2 style={{ color: C.text, margin: "0 0 20px", fontSize: 18 }}>{title}</h2>
        {children}
      </div>
    </div>
  );
}

// ─── Auth Form ───────────────────────────────────────
function AuthForm({ mode, onSwitch, onSuccess, showToast }) {
  const [form, setForm] = useState({ full_name: "", phone: "", password: "", payment_method: "Orange Money" });
  const [loading, setLoading] = useState(false);
  const h = k => e => setForm({ ...form, [k]: e.target.value });

  const submit = async () => {
    if (!form.phone || !form.password) { showToast("Remplissez tous les champs", "error"); return; }
    setLoading(true);
    if (mode === "register") {
      if (!form.full_name) { showToast("Entrez votre nom", "error"); setLoading(false); return; }
      const { error } = await api.signUp(form);
      if (error) { showToast(error.message, "error"); setLoading(false); return; }
      showToast("Compte créé ! Bonus 500 FCFA offert 🎉");
    } else {
      const { error } = await api.signIn(form);
      if (error) { showToast("Téléphone ou mot de passe incorrect", "error"); setLoading(false); return; }
      showToast("Bienvenue ! 🦁");
    }
    setLoading(false);
    onSuccess();
  };

  return (
    <div>
      {mode === "register" && <input style={inp} placeholder="Nom complet" value={form.full_name} onChange={h("full_name")} />}
      <input style={inp} placeholder="Numéro de téléphone" value={form.phone} onChange={h("phone")} />
      <input style={inp} type="password" placeholder="Mot de passe (min. 6 caractères)" value={form.password} onChange={h("password")} />
      {mode === "register" && (
        <>
          <label style={{ fontSize: 12, color: C.muted, display: "block", marginBottom: 6 }}>Moyen de paiement préféré</label>
          <select style={{ ...inp }} value={form.payment_method} onChange={h("payment_method")}>
            {PAYMENTS.map(p => <option key={p}>{p}</option>)}
          </select>
        </>
      )}
      <button onClick={submit} disabled={loading} style={{
        width: "100%", padding: 12, borderRadius: 10, border: "none",
        background: `linear-gradient(135deg, ${C.accent}, ${C.accentDark})`,
        color: "#0A0E1A", fontWeight: 800, fontSize: 14, cursor: "pointer", marginBottom: 12,
      }}>
        {loading ? "Chargement..." : mode === "login" ? "Se connecter" : "Créer mon compte gratuit"}
      </button>
      <div style={{ textAlign: "center", fontSize: 13, color: C.muted }}>
        {mode === "login" ? "Pas encore inscrit ? " : "Déjà un compte ? "}
        <span onClick={onSwitch} style={{ color: C.accent, cursor: "pointer", fontWeight: 700 }}>
          {mode === "login" ? "S'inscrire gratuitement" : "Se connecter"}
        </span>
      </div>
    </div>
  );
}

// ─── Deposit Modal ────────────────────────────────────
function DepositModal({ onClose, profile, onDeposited, showToast }) {
  const [amount, setAmount] = useState("");
  const [method, setMethod] = useState(profile?.payment_method || PAYMENTS[0]);
  const [loading, setLoading] = useState(false);
  const [done, setDone] = useState(false);
  const [newBal, setNewBal] = useState(0);

  const submit = async () => {
    if (!amount || parseFloat(amount) < 100) { showToast("Montant minimum : 100 FCFA", "error"); return; }
    setLoading(true);
    const { error, newBalance } = await api.deposit({
      userId: profile.id, amount: parseFloat(amount),
      method, currentBalance: profile.balance
    });
    setLoading(false);
    if (error) { showToast(error.message, "error"); return; }
    setNewBal(newBalance);
    setDone(true);
    onDeposited(newBalance);
  };

  if (done) return (
    <div style={{ textAlign: "center", padding: "20px 0" }}>
      <div style={{ fontSize: 52, marginBottom: 12 }}>✅</div>
      <div style={{ color: C.green, fontWeight: 800, fontSize: 20, marginBottom: 8 }}>Dépôt réussi !</div>
      <div style={{ color: C.muted, marginBottom: 16 }}>{parseInt(amount).toLocaleString()} FCFA via {method}</div>
      <div style={{ color: C.text, fontWeight: 700, fontSize: 16 }}>Nouveau solde : {newBal.toLocaleString()} FCFA</div>
      <button onClick={onClose} style={{ marginTop: 20, padding: "10px 28px", borderRadius: 10, border: "none", background: C.accent, color: "#0A0E1A", fontWeight: 700, cursor: "pointer" }}>
        Continuer à parier
      </button>
    </div>
  );

  return (
    <div>
      <div style={{ display: "flex", gap: 8, flexWrap: "wrap", marginBottom: 16 }}>
        {PAYMENTS.map(p => (
          <button key={p} onClick={() => setMethod(p)} style={{
            padding: "6px 12px", borderRadius: 20,
            border: `1px solid ${method === p ? C.accent : C.border}`,
            background: method === p ? C.accent + "22" : C.card,
            color: method === p ? C.accent : C.muted,
            cursor: "pointer", fontSize: 12, fontWeight: 600,
          }}>{p}</button>
        ))}
      </div>
      <div style={{ display: "flex", gap: 8, marginBottom: 14, flexWrap: "wrap" }}>
        {[1000, 2000, 5000, 10000].map(v => (
          <button key={v} onClick={() => setAmount(String(v))} style={{
            flex: 1, padding: "9px 4px", borderRadius: 8,
            border: `1px solid ${amount === String(v) ? C.accent : C.border}`,
            background: amount === String(v) ? C.accent + "22" : C.card,
            color: amount === String(v) ? C.accent : C.text,
            cursor: "pointer", fontSize: 13, fontWeight: 700,
          }}>{v.toLocaleString()}</button>
        ))}
      </div>
      <input type="number" placeholder="Autre montant (FCFA)" value={amount} onChange={e => setAmount(e.target.value)} style={inp} />
      <div style={{ background: C.highlight, borderRadius: 8, padding: "10px 14px", marginBottom: 14, fontSize: 13, color: C.muted }}>
        Solde actuel : <strong style={{ color: C.green }}>{profile?.balance?.toLocaleString()} FCFA</strong>
      </div>
      <button onClick={submit} disabled={loading} style={{
        width: "100%", padding: 12, borderRadius: 10, border: "none",
        background: `linear-gradient(135deg, ${C.accent}, ${C.accentDark})`,
        color: "#0A0E1A", fontWeight: 800, cursor: "pointer",
      }}>
        {loading ? "Traitement..." : `Déposer via ${method}`}
      </button>
    </div>
  );
}

// ─── Odd Button ──────────────────────────────────────
function OddBtn({ label, value, selected, onClick }) {
  return (
    <button onClick={onClick} style={{
      background: selected ? C.accent : C.highlight,
      border: `1px solid ${selected ? C.accent : C.border}`,
      color: selected ? "#0A0E1A" : C.text,
      borderRadius: 8, padding: "6px 10px", cursor: "pointer",
      transition: "all .2s", minWidth: 72, fontSize: 13,
    }}>
      <div style={{ fontSize: 10, color: selected ? "#0A0E1A" : C.muted, marginBottom: 2 }}>{label}</div>
      <div style={{ fontSize: 15, fontWeight: 700 }}>{value}</div>
    </button>
  );
}

// ─── Match Card ──────────────────────────────────────
function MatchCard({ match, betSlip, onBet }) {
  const inSlip = type => betSlip.some(b => b.matchId === match.id && b.type === type);
  const time = new Date(match.match_time).toLocaleTimeString("fr", { hour: "2-digit", minute: "2-digit" });

  return (
    <div style={{ background: C.card, border: `1px solid ${C.border}`, borderRadius: 12, padding: 16, marginBottom: 12 }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 10 }}>
        <span style={{ fontSize: 11, color: C.muted, background: C.highlight, padding: "2px 8px", borderRadius: 20 }}>{match.league}</span>
        <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
          {match.status === "live" && (
            <span style={{ fontSize: 11, color: C.green, background: "#00C85322", padding: "2px 8px", borderRadius: 20, display: "flex", alignItems: "center", gap: 4 }}>
              <span style={{ width: 6, height: 6, borderRadius: "50%", background: C.green, display: "inline-block" }} /> LIVE {match.home_score} - {match.away_score}
            </span>
          )}
          <span style={{ fontSize: 12, color: C.muted }}>{time}</span>
        </div>
      </div>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 12 }}>
        <span style={{ fontWeight: 700, fontSize: 14 }}>{match.home_team}</span>
        <span style={{ color: C.muted, fontSize: 12 }}>VS</span>
        <span style={{ fontWeight: 700, fontSize: 14 }}>{match.away_team}</span>
      </div>
      <div style={{ display: "flex", gap: 8, justifyContent: "center" }}>
        <OddBtn label="1" value={match.home_odd} selected={inSlip("home")} onClick={() => onBet(match, "home", match.home_odd, match.home_team)} />
        {match.draw_odd && <OddBtn label="N" value={match.draw_odd} selected={inSlip("draw")} onClick={() => onBet(match, "draw", match.draw_odd, "Nul")} />}
        <OddBtn label="2" value={match.away_odd} selected={inSlip("away")} onClick={() => onBet(match, "away", match.away_odd, match.away_team)} />
      </div>
    </div>
  );
}

// ─── Bet Slip ────────────────────────────────────────
function BetSlip({ betSlip, onRemove, onClear, profile, onBetPlaced, showToast, openAuth }) {
  const [stake, setStake] = useState("");
  const [loading, setLoading] = useState(false);
  const totalOdd = betSlip.reduce((a, b) => a * b.odd, 1);
  const gain = stake ? Math.round(parseFloat(stake) * totalOdd) : 0;

  const confirm = async () => {
    if (!profile) { openAuth(); return; }
    if (!stake || parseFloat(stake) < 100) { showToast("Mise minimum : 100 FCFA", "error"); return; }
    setLoading(true);
    const { error } = await api.placeBet({
      userId: profile.id, stake: parseFloat(stake),
      totalOdd: parseFloat(totalOdd.toFixed(2)),
      potentialGain: gain, betType: betSlip.length > 1 ? "combined" : "simple",
      selections: betSlip, currentBalance: profile.balance,
    });
    setLoading(false);
    if (error) { showToast(error.message, "error"); return; }
    showToast(`Pari de ${parseInt(stake).toLocaleString()} FCFA validé ! Gain potentiel : ${gain.toLocaleString()} FCFA 🎯`);
    onBetPlaced(parseFloat(stake));
    onClear();
    setStake("");
  };

  return (
    <div style={{ background: C.card, border: `1px solid ${C.border}`, borderRadius: 12, padding: 16, position: "sticky", top: 16 }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 12 }}>
        <h3 style={{ color: C.accent, margin: 0, fontSize: 15, fontWeight: 800 }}>🎫 Coupon ({betSlip.length})</h3>
        {betSlip.length > 0 && <button onClick={onClear} style={{ background: "none", border: "none", color: C.red, cursor: "pointer", fontSize: 12 }}>Vider</button>}
      </div>

      {betSlip.length === 0 ? (
        <div style={{ textAlign: "center", color: C.muted, padding: "32px 0", fontSize: 13 }}>Cliquez sur une cote pour parier</div>
      ) : (
        <>
          <div style={{ maxHeight: 200, overflowY: "auto", marginBottom: 12 }}>
            {betSlip.map(b => (
              <div key={b.id} style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "8px 0", borderBottom: `1px solid ${C.border}` }}>
                <div>
                  <div style={{ fontSize: 12, fontWeight: 600 }}>{b.home} vs {b.away}</div>
                  <div style={{ fontSize: 11, color: C.muted }}>{b.label}</div>
                </div>
                <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
                  <span style={{ color: C.accent, fontWeight: 700 }}>{b.odd}</span>
                  <button onClick={() => onRemove(b.id)} style={{ background: "none", border: "none", color: C.red, cursor: "pointer", fontSize: 16, padding: 0, lineHeight: 1 }}>×</button>
                </div>
              </div>
            ))}
          </div>

          <div style={{ background: C.highlight, borderRadius: 8, padding: "10px 12px", marginBottom: 12 }}>
            <div style={{ display: "flex", justifyContent: "space-between", fontSize: 12, marginBottom: 4 }}>
              <span style={{ color: C.muted }}>Cote totale</span>
              <span style={{ color: C.accent, fontWeight: 700 }}>{totalOdd.toFixed(2)}</span>
            </div>
            {profile && (
              <div style={{ display: "flex", justifyContent: "space-between", fontSize: 12 }}>
                <span style={{ color: C.muted }}>Solde</span>
                <span style={{ color: C.green, fontWeight: 700 }}>{profile.balance?.toLocaleString()} FCFA</span>
              </div>
            )}
          </div>

          <input type="number" placeholder="Mise (FCFA)" value={stake} onChange={e => setStake(e.target.value)}
            style={{ ...inp, marginBottom: 10 }} />

          {stake && (
            <div style={{ background: "#00C85318", border: `1px solid ${C.green}33`, borderRadius: 8, padding: "8px 12px", marginBottom: 10, display: "flex", justifyContent: "space-between" }}>
              <span style={{ color: C.muted, fontSize: 12 }}>Gain potentiel</span>
              <span style={{ color: C.green, fontWeight: 800 }}>{gain.toLocaleString()} FCFA</span>
            </div>
          )}

          <button onClick={confirm} disabled={loading} style={{
            width: "100%", padding: 12, borderRadius: 10, border: "none",
            background: `linear-gradient(135deg, ${C.accent}, ${C.accentDark})`,
            color: "#0A0E1A", fontWeight: 800, fontSize: 14, cursor: "pointer",
          }}>
            {loading ? "Validation..." : profile ? "Valider le pari" : "Connectez-vous pour parier"}
          </button>
        </>
      )}
    </div>
  );
}

// ─── History Tab ──────────────────────────────────────
function HistoryTab({ userId, showToast }) {
  const [bets, setBets] = useState([]);
  const [txs, setTxs] = useState([]);
  const [view, setView] = useState("bets");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!userId) return;
    (async () => {
      setLoading(true);
      const [{ data: b }, { data: t }] = await Promise.all([
        api.getUserBets(userId), api.getTransactions(userId)
      ]);
      setBets(b || []);
      setTxs(t || []);
      setLoading(false);
    })();
  }, [userId]);

  const statusColor = s => s === "won" ? C.green : s === "lost" ? C.red : C.accent;
  const statusLabel = s => s === "won" ? "Gagné 🏆" : s === "lost" ? "Perdu" : "En cours";

  if (loading) return <div style={{ textAlign: "center", color: C.muted, padding: 60 }}>Chargement...</div>;

  return (
    <div>
      <div style={{ display: "flex", gap: 8, marginBottom: 20 }}>
        {["bets", "transactions"].map(v => (
          <button key={v} onClick={() => setView(v)} style={{
            padding: "8px 18px", borderRadius: 20,
            border: `1px solid ${view === v ? C.accent : C.border}`,
            background: view === v ? C.accent + "22" : C.card,
            color: view === v ? C.accent : C.muted,
            cursor: "pointer", fontWeight: 600, fontSize: 13,
          }}>{v === "bets" ? "📋 Mes paris" : "💳 Transactions"}</button>
        ))}
      </div>

      {view === "bets" && (bets.length === 0 ? (
        <div style={{ textAlign: "center", color: C.muted, padding: 60 }}>
          <div style={{ fontSize: 40, marginBottom: 12 }}>🎯</div>
          Aucun pari pour le moment
        </div>
      ) : bets.map(b => (
        <div key={b.id} style={{ background: C.card, border: `1px solid ${C.border}`, borderRadius: 12, padding: 16, marginBottom: 12 }}>
          <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 10 }}>
            <span style={{ fontSize: 12, color: C.muted }}>{new Date(b.created_at).toLocaleDateString("fr")}</span>
            <span style={{ fontSize: 12, color: statusColor(b.status), background: statusColor(b.status) + "22", padding: "2px 10px", borderRadius: 20, fontWeight: 700 }}>
              {statusLabel(b.status)}
            </span>
          </div>
          {b.bet_selections?.map((s, i) => (
            <div key={i} style={{ fontSize: 13, color: C.text, marginBottom: 4 }}>
              ▸ {s.matches?.home_team} vs {s.matches?.away_team} — <span style={{ color: C.accent }}>@ {s.odd}</span>
            </div>
          ))}
          <div style={{ display: "flex", gap: 20, marginTop: 12, paddingTop: 10, borderTop: `1px solid ${C.border}` }}>
            <div><span style={{ color: C.muted, fontSize: 11 }}>Mise </span><span style={{ fontWeight: 700 }}>{b.stake?.toLocaleString()} FCFA</span></div>
            <div><span style={{ color: C.muted, fontSize: 11 }}>Cote </span><span style={{ color: C.accent, fontWeight: 700 }}>x{b.total_odd}</span></div>
            <div><span style={{ color: C.muted, fontSize: 11 }}>Gain pot. </span><span style={{ color: C.green, fontWeight: 700 }}>{b.potential_gain?.toLocaleString()} FCFA</span></div>
          </div>
        </div>
      )))}

      {view === "transactions" && (txs.length === 0 ? (
        <div style={{ textAlign: "center", color: C.muted, padding: 60 }}>Aucune transaction</div>
      ) : txs.map(t => (
        <div key={t.id} style={{ background: C.card, border: `1px solid ${C.border}`, borderRadius: 12, padding: 14, marginBottom: 10, display: "flex", justifyContent: "space-between", alignItems: "center" }}>
          <div>
            <div style={{ fontWeight: 600, fontSize: 13, textTransform: "capitalize" }}>{t.type === "deposit" ? "💳 Dépôt" : t.type === "bet" ? "🎫 Pari" : t.type === "bonus" ? "🎁 Bonus" : "💰 Gain"}</div>
            <div style={{ fontSize: 11, color: C.muted }}>{t.method} · {new Date(t.created_at).toLocaleDateString("fr")}</div>
          </div>
          <div style={{ fontWeight: 800, fontSize: 15, color: t.amount > 0 ? C.green : C.red }}>
            {t.amount > 0 ? "+" : ""}{t.amount?.toLocaleString()} FCFA
          </div>
        </div>
      )))}
    </div>
  );
}

// ─── Main App ─────────────────────────────────────────
export default function BetAfrik() {
  const [session, setSession] = useState(null);
  const [profile, setProfile] = useState(null);
  const [matches, setMatches] = useState([]);
  const [sport, setSport] = useState("foot");
  const [betSlip, setBetSlip] = useState([]);
  const [modal, setModal] = useState(null);
  const [authMode, setAuthMode] = useState("login");
  const [activeTab, setActiveTab] = useState("home");
  const [toast, setToast] = useState(null);
  const [loadingMatches, setLoadingMatches] = useState(true);

  const showToast = useCallback((msg, type = "success") => {
    setToast({ msg, type });
    setTimeout(() => setToast(null), 3500);
  }, []);

  // Auth listener
  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session } }) => setSession(session));
    const { data: { subscription } } = supabase.auth.onAuthStateChange((_e, s) => setSession(s));
    return () => subscription.unsubscribe();
  }, []);

  // Load profile when session changes
  useEffect(() => {
    if (session?.user) {
      api.getProfile(session.user.id).then(({ data }) => setProfile(data));
    } else {
      setProfile(null);
    }
  }, [session]);

  // Load matches
  useEffect(() => {
    setLoadingMatches(true);
    api.getMatches(sport).then(({ data }) => {
      setMatches(data || []);
      setLoadingMatches(false);
    });
  }, [sport]);

  // Realtime: match updates
  useEffect(() => {
    const channel = supabase.channel("matches-live")
      .on("postgres_changes", { event: "UPDATE", schema: "public", table: "matches" }, payload => {
        setMatches(prev => prev.map(m => m.id === payload.new.id ? payload.new : m));
      })
      .subscribe();
    return () => supabase.removeChannel(channel);
  }, []);

  const handleBet = (match, type, odd, label) => {
    if (!session) { setAuthMode("login"); setModal("auth"); return; }
    const existing = betSlip.find(b => b.matchId === match.id);
    if (existing) {
      if (existing.type === type) setBetSlip(betSlip.filter(b => b.matchId !== match.id));
      else setBetSlip(betSlip.map(b => b.matchId === match.id ? { ...b, type, odd, label } : b));
    } else {
      setBetSlip([...betSlip, { id: Date.now(), matchId: match.id, home: match.home_team, away: match.away_team, type, odd, label }]);
    }
  };

  const handleBetPlaced = (stake) => {
    setProfile(prev => prev ? { ...prev, balance: prev.balance - stake } : prev);
  };

  const handleDeposited = (newBal) => {
    setProfile(prev => prev ? { ...prev, balance: newBal } : prev);
  };

  const handleSignOut = async () => {
    await api.signOut();
    setBetSlip([]);
    setActiveTab("home");
    showToast("Déconnexion réussie");
  };

  const filteredMatches = matches.filter(m => m.sport === sport);
  const liveMatches = matches.filter(m => m.status === "live");

  return (
    <div style={{ minHeight: "100vh", background: C.bg, fontFamily: "'Inter',sans-serif", color: C.text }}>
      <style>{`
        *{box-sizing:border-box} input,select{outline:none} input::placeholder{color:#6B7A99}
        @keyframes slideIn{from{transform:translateY(-20px);opacity:0}to{transform:translateY(0);opacity:1}}
        ::-webkit-scrollbar{width:4px} ::-webkit-scrollbar-thumb{background:#1E2D45;border-radius:4px}
      `}</style>

      {toast && <Toast msg={toast.msg} type={toast.type} />}

      {/* HEADER */}
      <header style={{ background: C.surface, borderBottom: `1px solid ${C.border}`, padding: "0 20px", position: "sticky", top: 0, zIndex: 100 }}>
        <div style={{ maxWidth: 1100, margin: "0 auto", display: "flex", justifyContent: "space-between", alignItems: "center", height: 60 }}>
          <div style={{ display: "flex", alignItems: "center", gap: 10, cursor: "pointer" }} onClick={() => setActiveTab("home")}>
            <span style={{ fontSize: 24 }}>🦁</span>
            <span style={{ fontWeight: 900, fontSize: 20, color: C.accent, letterSpacing: -0.5 }}>BetAfrik</span>
            <span style={{ fontSize: 10, color: C.muted, background: C.highlight, padding: "2px 6px", borderRadius: 10 }}>v2.0</span>
          </div>
          <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
            {profile ? (
              <>
                <button onClick={() => setModal("deposit")} style={{ background: C.highlight, border: `1px solid ${C.border}`, padding: "7px 14px", borderRadius: 20, fontSize: 13, cursor: "pointer", color: C.text }}>
                  <span style={{ color: C.green, fontWeight: 800 }}>{profile.balance?.toLocaleString()} FCFA</span> · <span style={{ color: C.muted, fontSize: 12 }}>+ Déposer</span>
                </button>
                <div onClick={() => setActiveTab("profile")} style={{ width: 36, height: 36, borderRadius: "50%", background: `linear-gradient(135deg,${C.accent},${C.accentDark})`, display: "flex", alignItems: "center", justifyContent: "center", fontWeight: 900, color: "#0A0E1A", cursor: "pointer", fontSize: 15 }}>
                  {profile.full_name?.[0]?.toUpperCase() || "U"}
                </div>
              </>
            ) : (
              <button onClick={() => { setAuthMode("login"); setModal("auth"); }} style={{
                padding: "8px 20px", borderRadius: 20, border: "none",
                background: `linear-gradient(135deg,${C.accent},${C.accentDark})`,
                color: "#0A0E1A", fontWeight: 800, cursor: "pointer", fontSize: 13,
              }}>Connexion / Inscription</button>
            )}
          </div>
        </div>
      </header>

      {/* NAV */}
      <nav style={{ background: C.surface, borderBottom: `1px solid ${C.border}` }}>
        <div style={{ maxWidth: 1100, margin: "0 auto", display: "flex", overflowX: "auto" }}>
          {[
            { id: "home", label: "🏠 Accueil" },
            { id: "live", label: `🔴 Live${liveMatches.length > 0 ? ` (${liveMatches.length})` : ""}` },
            { id: "history", label: "📋 Mes paris" },
            { id: "profile", label: "👤 Profil" },
          ].map(t => (
            <button key={t.id} onClick={() => setActiveTab(t.id)} style={{
              padding: "14px 20px", border: "none", background: "none",
              color: activeTab === t.id ? C.accent : C.muted,
              borderBottom: `2px solid ${activeTab === t.id ? C.accent : "transparent"}`,
              cursor: "pointer", fontSize: 13, fontWeight: 600, whiteSpace: "nowrap",
            }}>{t.label}</button>
          ))}
        </div>
      </nav>

      {/* HERO */}
      {activeTab === "home" && (
        <div style={{ background: "linear-gradient(135deg,#0F1E38,#1A2D50,#0F1E38)", borderBottom: `1px solid ${C.border}`, padding: "28px 20px" }}>
          <div style={{ maxWidth: 1100, margin: "0 auto", display: "flex", justifyContent: "space-between", alignItems: "center", flexWrap: "wrap", gap: 20 }}>
            <div>
              <div style={{ fontSize: 11, color: C.accent, fontWeight: 700, letterSpacing: 2, marginBottom: 8 }}>🌍 LA PLATEFORME #1 DE PARIS EN AFRIQUE</div>
              <h1 style={{ margin: 0, fontSize: 28, fontWeight: 900, lineHeight: 1.2 }}>
                Pariez. Gagnez.<br /><span style={{ color: C.accent }}>Retirez en Mobile Money.</span>
              </h1>
              <p style={{ color: C.muted, marginTop: 10, marginBottom: 0, fontSize: 14 }}>Paris sécurisés · Cotes compétitives · Paiement instantané</p>
            </div>
            <div style={{ display: "flex", gap: 28 }}>
              {[["50K+","Joueurs"],["200+","Matchs/jour"],["x100","Cote max"]].map(([v,l]) => (
                <div key={l} style={{ textAlign: "center" }}>
                  <div style={{ fontSize: 24, fontWeight: 900, color: C.accent }}>{v}</div>
                  <div style={{ fontSize: 11, color: C.muted }}>{l}</div>
                </div>
              ))}
            </div>
            {!session && (
              <button onClick={() => { setAuthMode("register"); setModal("auth"); }} style={{
                padding: "13px 26px", borderRadius: 10, border: "none",
                background: `linear-gradient(135deg,${C.accent},${C.accentDark})`,
                color: "#0A0E1A", fontWeight: 900, cursor: "pointer", fontSize: 15,
              }}>🎁 Créer un compte — 500 FCFA offerts</button>
            )}
          </div>
        </div>
      )}

      {/* CONTENT */}
      <div style={{ maxWidth: 1100, margin: "0 auto", padding: "20px 16px" }}>

        {/* HOME */}
        {activeTab === "home" && (
          <div style={{ display: "grid", gridTemplateColumns: "1fr 320px", gap: 20 }}>
            <div>
              <div style={{ display: "flex", gap: 8, marginBottom: 20, overflowX: "auto" }}>
                {SPORTS.map(s => (
                  <button key={s.id} onClick={() => setSport(s.id)} style={{
                    padding: "8px 16px", borderRadius: 20, whiteSpace: "nowrap",
                    border: `1px solid ${sport === s.id ? C.accent : C.border}`,
                    background: sport === s.id ? C.accent + "22" : C.card,
                    color: sport === s.id ? C.accent : C.muted,
                    cursor: "pointer", fontSize: 13, fontWeight: 600,
                  }}>{s.label}</button>
                ))}
              </div>
              {loadingMatches ? (
                <div style={{ textAlign: "center", color: C.muted, padding: 60 }}>Chargement des matchs...</div>
              ) : filteredMatches.length === 0 ? (
                <div style={{ textAlign: "center", color: C.muted, padding: 60 }}>Aucun match disponible</div>
              ) : filteredMatches.map(m => (
                <MatchCard key={m.id} match={m} betSlip={betSlip} onBet={handleBet} />
              ))}
            </div>
            <BetSlip betSlip={betSlip} onRemove={id => setBetSlip(betSlip.filter(b => b.id !== id))} onClear={() => setBetSlip([])} profile={profile} onBetPlaced={handleBetPlaced} showToast={showToast} openAuth={() => { setAuthMode("login"); setModal("auth"); }} />
          </div>
        )}

        {/* LIVE */}
        {activeTab === "live" && (
          <div style={{ display: "grid", gridTemplateColumns: "1fr 320px", gap: 20 }}>
            <div>
              <h2 style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 16 }}>
                <span style={{ width: 10, height: 10, borderRadius: "50%", background: C.green, display: "inline-block", animation: "slideIn 1s infinite alternate" }} />
                Matchs en direct
              </h2>
              {liveMatches.length === 0 ? (
                <div style={{ textAlign: "center", color: C.muted, padding: 60 }}>
                  <div style={{ fontSize: 40, marginBottom: 12 }}>📺</div>
                  Aucun match en direct pour le moment
                </div>
              ) : liveMatches.map(m => (
                <MatchCard key={m.id} match={m} betSlip={betSlip} onBet={handleBet} />
              ))}
            </div>
            <BetSlip betSlip={betSlip} onRemove={id => setBetSlip(betSlip.filter(b => b.id !== id))} onClear={() => setBetSlip([])} profile={profile} onBetPlaced={handleBetPlaced} showToast={showToast} openAuth={() => { setAuthMode("login"); setModal("auth"); }} />
          </div>
        )}

        {/* HISTORY */}
        {activeTab === "history" && (
          !session ? (
            <div style={{ textAlign: "center", padding: "80px 0", color: C.muted }}>
              <div style={{ fontSize: 48, marginBottom: 16 }}>🔒</div>
              <div style={{ marginBottom: 20, fontSize: 15 }}>Connectez-vous pour voir vos paris et transactions</div>
              <button onClick={() => { setAuthMode("login"); setModal("auth"); }} style={{ padding: "11px 26px", borderRadius: 10, border: "none", background: C.accent, color: "#0A0E1A", fontWeight: 800, cursor: "pointer" }}>Se connecter</button>
            </div>
          ) : <HistoryTab userId={session.user.id} showToast={showToast} />
        )}

        {/* PROFILE */}
        {activeTab === "profile" && (
          !session ? (
            <div style={{ textAlign: "center", padding: "80px 0", color: C.muted }}>
              <div style={{ fontSize: 48, marginBottom: 16 }}>👤</div>
              <button onClick={() => { setAuthMode("login"); setModal("auth"); }} style={{ padding: "11px 26px", borderRadius: 10, border: "none", background: C.accent, color: "#0A0E1A", fontWeight: 800, cursor: "pointer" }}>Se connecter</button>
            </div>
          ) : profile && (
            <div style={{ maxWidth: 500 }}>
              <h2 style={{ marginBottom: 20 }}>👤 Mon profil</h2>
              <div style={{ background: C.card, border: `1px solid ${C.border}`, borderRadius: 14, padding: 20, marginBottom: 16 }}>
                <div style={{ display: "flex", alignItems: "center", gap: 16, marginBottom: 20 }}>
                  <div style={{ width: 58, height: 58, borderRadius: "50%", background: `linear-gradient(135deg,${C.accent},${C.accentDark})`, display: "flex", alignItems: "center", justifyContent: "center", fontWeight: 900, color: "#0A0E1A", fontSize: 24 }}>
                    {profile.full_name?.[0]?.toUpperCase()}
                  </div>
                  <div>
                    <div style={{ fontWeight: 800, fontSize: 17 }}>{profile.full_name}</div>
                    <div style={{ color: C.muted, fontSize: 13 }}>📱 {profile.phone}</div>
                    <div style={{ color: C.muted, fontSize: 12 }}>💳 {profile.payment_method}</div>
                  </div>
                </div>
                <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 }}>
                  {[
                    { l: "Solde principal", v: `${profile.balance?.toLocaleString()} FCFA`, c: C.green },
                    { l: "Bonus", v: `${profile.bonus?.toLocaleString()} FCFA`, c: C.accent },
                  ].map(s => (
                    <div key={s.l} style={{ background: C.highlight, borderRadius: 10, padding: 14 }}>
                      <div style={{ color: C.muted, fontSize: 11, marginBottom: 4 }}>{s.l}</div>
                      <div style={{ color: s.c, fontWeight: 800, fontSize: 18 }}>{s.v}</div>
                    </div>
                  ))}
                </div>
              </div>
              <div style={{ display: "flex", gap: 10 }}>
                <button onClick={() => setModal("deposit")} style={{ flex: 1, padding: 12, borderRadius: 10, border: "none", background: `linear-gradient(135deg,${C.accent},${C.accentDark})`, color: "#0A0E1A", fontWeight: 800, cursor: "pointer" }}>
                  💳 Déposer des fonds
                </button>
                <button onClick={handleSignOut} style={{ flex: 1, padding: 12, borderRadius: 10, border: `1px solid ${C.red}`, background: "none", color: C.red, fontWeight: 700, cursor: "pointer" }}>
                  Déconnexion
                </button>
              </div>
            </div>
          )
        )}
      </div>

      {/* MODALS */}
      {modal === "auth" && (
        <Modal title={authMode === "login" ? "🔐 Connexion" : "🎁 Créer un compte gratuit"} onClose={() => setModal(null)}>
          <AuthForm mode={authMode} onSwitch={() => setAuthMode(authMode === "login" ? "register" : "login")} onSuccess={() => setModal(null)} showToast={showToast} />
        </Modal>
      )}
      {modal === "deposit" && profile && (
        <Modal title="💳 Déposer des fonds" onClose={() => setModal(null)}>
          <DepositModal onClose={() => setModal(null)} profile={profile} onDeposited={handleDeposited} showToast={showToast} />
        </Modal>
      )}

      {/* FOOTER */}
      <footer style={{ borderTop: `1px solid ${C.border}`, padding: "20px 16px", marginTop: 40, textAlign: "center" }}>
        <div style={{ color: C.muted, fontSize: 12, marginBottom: 6 }}>
          🦁 <strong style={{ color: C.accent }}>BetAfrik v2.0</strong> — Powered by Supabase · Hébergé sur Netlify/Render
        </div>
        <div style={{ color: C.muted, fontSize: 11 }}>18+ · Jouez responsable · Licence Nationale des Jeux · Mobile Money Afrique</div>
      </footer>
    </div>
  );
}
