-- =============================================
-- BETAFRIK — Schéma Supabase complet
-- Collez ce SQL dans : Supabase → SQL Editor → Run
-- =============================================

-- 1. TABLE PROFILS UTILISATEURS
create table if not exists public.profiles (
  id uuid references auth.users(id) on delete cascade primary key,
  full_name text not null,
  phone text unique not null,
  payment_method text default 'Orange Money',
  balance numeric(12,2) default 5000.00,
  bonus numeric(12,2) default 500.00,
  is_verified boolean default false,
  created_at timestamptz default now()
);

-- 2. TABLE MATCHS
create table if not exists public.matches (
  id serial primary key,
  sport text not null,
  league text not null,
  home_team text not null,
  away_team text not null,
  home_odd numeric(5,2) not null,
  draw_odd numeric(5,2),
  away_odd numeric(5,2) not null,
  match_time timestamptz not null,
  status text default 'upcoming', -- upcoming | live | finished
  home_score int default 0,
  away_score int default 0,
  result text, -- home | draw | away
  created_at timestamptz default now()
);

-- 3. TABLE PARIS
create table if not exists public.bets (
  id uuid default gen_random_uuid() primary key,
  user_id uuid references public.profiles(id) on delete cascade,
  stake numeric(12,2) not null,
  total_odd numeric(10,2) not null,
  potential_gain numeric(12,2) not null,
  status text default 'pending', -- pending | won | lost | cancelled
  bet_type text default 'combined', -- simple | combined
  created_at timestamptz default now()
);

-- 4. TABLE SÉLECTIONS (détail d'un pari)
create table if not exists public.bet_selections (
  id uuid default gen_random_uuid() primary key,
  bet_id uuid references public.bets(id) on delete cascade,
  match_id int references public.matches(id),
  selection text not null, -- home | draw | away
  odd numeric(5,2) not null,
  result text -- pending | won | lost
);

-- 5. TABLE TRANSACTIONS
create table if not exists public.transactions (
  id uuid default gen_random_uuid() primary key,
  user_id uuid references public.profiles(id) on delete cascade,
  type text not null, -- deposit | withdrawal | bet | win | bonus
  amount numeric(12,2) not null,
  method text, -- Orange Money | Wave | MTN MoMo | etc
  status text default 'completed', -- pending | completed | failed
  reference text unique default gen_random_uuid()::text,
  created_at timestamptz default now()
);

-- =============================================
-- SÉCURITÉ : Row Level Security (RLS)
-- =============================================

alter table public.profiles enable row level security;
alter table public.bets enable row level security;
alter table public.bet_selections enable row level security;
alter table public.transactions enable row level security;
alter table public.matches enable row level security;

-- Profils : chaque user voit/modifie seulement le sien
create policy "Voir son profil" on public.profiles for select using (auth.uid() = id);
create policy "Modifier son profil" on public.profiles for update using (auth.uid() = id);

-- Paris : chaque user voit/crée ses propres paris
create policy "Voir ses paris" on public.bets for select using (auth.uid() = user_id);
create policy "Créer un pari" on public.bets for insert with check (auth.uid() = user_id);

-- Sélections
create policy "Voir ses sélections" on public.bet_selections for select
  using (exists (select 1 from public.bets where bets.id = bet_id and bets.user_id = auth.uid()));
create policy "Créer sélections" on public.bet_selections for insert
  with check (exists (select 1 from public.bets where bets.id = bet_id and bets.user_id = auth.uid()));

-- Transactions : lecture seule pour l'utilisateur
create policy "Voir ses transactions" on public.transactions for select using (auth.uid() = user_id);
create policy "Créer transaction" on public.transactions for insert with check (auth.uid() = user_id);

-- Matchs : tout le monde peut lire
create policy "Voir les matchs" on public.matches for select using (true);

-- =============================================
-- TRIGGER : Créer profil automatiquement à l'inscription
-- =============================================

create or replace function public.handle_new_user()
returns trigger language plpgsql security definer as $$
begin
  insert into public.profiles (id, full_name, phone, payment_method)
  values (
    new.id,
    coalesce(new.raw_user_meta_data->>'full_name', 'Joueur'),
    coalesce(new.raw_user_meta_data->>'phone', new.email),
    coalesce(new.raw_user_meta_data->>'payment_method', 'Orange Money')
  );
  -- Bonus de bienvenue de 500 FCFA
  insert into public.transactions (user_id, type, amount, method, status)
  values (new.id, 'bonus', 500, 'BetAfrik', 'completed');
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();

-- =============================================
-- DONNÉES DE TEST : Matchs
-- =============================================

insert into public.matches (sport, league, home_team, away_team, home_odd, draw_odd, away_odd, match_time, status, home_score, away_score) values
('foot', 'AFCON 2026', 'Sénégal', 'Maroc', 2.10, 3.20, 3.50, now() + interval '2 hours', 'live', 1, 0),
('foot', 'CAN U23', 'Nigeria', 'Ghana', 1.85, 3.40, 4.10, now() + interval '4 hours', 'upcoming', 0, 0),
('foot', 'Liga Africaine', 'Al Ahly', 'Wydad', 1.60, 3.50, 5.00, now() + interval '6 hours', 'upcoming', 0, 0),
('basket', 'NBA Africa', 'Lagos Lions', 'Cairo Kings', 1.75, null, 2.10, now() + interval '1 hour', 'live', 68, 71),
('tennis', 'Roland Garros', 'Djokovic', 'Alcaraz', 2.20, null, 1.70, now() + interval '3 hours', 'upcoming', 0, 0),
('rugby', 'Afrique du Sud', 'Springboks', 'Kenya', 1.15, 12.00, 7.50, now() + interval '5 hours', 'upcoming', 0, 0),
('foot', 'AFCON 2026', 'Côte d''Ivoire', 'Cameroun', 2.30, 3.10, 3.00, now() + interval '8 hours', 'upcoming', 0, 0),
('foot', 'Premier League Afrique', 'Kaizer Chiefs', 'Orlando Pirates', 2.50, 3.00, 2.80, now() + interval '10 hours', 'upcoming', 0, 0);

select 'Schéma BetAfrik installé avec succès ! 🦁' as message;
